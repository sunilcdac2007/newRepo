My programs require an input file. The file "FamilytreeTest.txt" is provided as an example.

This is standalone  application where no any third party library required.

User can run this program through Geektrust.java file and they can pass the test file path argument.
        Example : java Geektrust.java "F:\\FamilytreeTest.txt"

Scope of this project:
 I supporting limited relation ship implmented in com.family.relation package.
 
 Langauage: JDK 11
 Runtime environemnt : JRE 11