package com.family.relation;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.family.bean.Person;
import com.family.util.PersonUtil;

public class RelationshipManager {
	
	private Map<RelationType, Relation> relationshipClassMapping;
	
	public RelationshipManager() {
		relationshipClassMapping = new HashMap<RelationType, Relation>();
		relationshipClassMapping.put(RelationType.BROTHERINLAW,
				new BrotherInLaw());
		relationshipClassMapping.put(RelationType.SISTERINLAW, new SisterInLaw());
		relationshipClassMapping.put(RelationType.BROTHERS,
				new Brother());
		relationshipClassMapping.put(RelationType.SISTERS, new Sister());
		
		relationshipClassMapping.put(RelationType.DAUGHTER,
				new Doughter());
		relationshipClassMapping.put(RelationType.SON, new Son());
		relationshipClassMapping.put(RelationType.MATERNALAUNT,
				new MaternalAunt());
		relationshipClassMapping.put(RelationType.MATERNALUNCLE, new MaternalUncle());
		relationshipClassMapping.put(RelationType.PATERNALAUNT,
				new PaternalAunt());
		relationshipClassMapping.put(RelationType.PATERNALUNCLE, new PaternalUncle());
		relationshipClassMapping.put(RelationType.SIBLING, new Sibling());
		
	}
	
	public Set<Person> getPeopleWithRelationship(
			RelationType relationship, Person person) {

		Relation relation = relationshipClassMapping.get(relationship);

		return relation.getInstance().get(person);
	}

}
