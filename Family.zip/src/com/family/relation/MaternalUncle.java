package com.family.relation;

import java.util.Set;
import java.util.stream.Collectors;

import com.family.bean.GenderType;
import com.family.bean.Person;

public class MaternalUncle implements Relation {

	public Set<Person> get(Person currentPerson){
		return currentPerson.getMonther().getSiblings().stream()
				   .filter(person -> person.getGender().equals(GenderType.MALE) )
				   .collect(Collectors.toSet());
	}
	public MaternalUncle getInstance() {
		return new MaternalUncle();
	}


}
