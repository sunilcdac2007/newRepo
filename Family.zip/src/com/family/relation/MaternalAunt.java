package com.family.relation;

import java.util.Set;
import java.util.stream.Collectors;

import com.family.bean.GenderType;
import com.family.bean.Person;

public class MaternalAunt implements Relation {

	public Set<Person> get(Person currentPerson){
		return currentPerson.getMonther().getSiblings().stream()
				   .filter(person -> person.getGender().equals(GenderType.FEMALE) )
				   .collect(Collectors.toSet());
	}
	public MaternalAunt getInstance() {
		return new MaternalAunt();
	}

}
