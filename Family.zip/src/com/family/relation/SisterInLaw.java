package com.family.relation;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import com.family.bean.GenderType;
import com.family.bean.Person;

public class SisterInLaw implements Relation {
	
	public Set<Person> get(Person currentPerson){
		Set<Person> brotherInLaw = currentPerson.getSpouse().getSiblings().stream()
		   .filter(person -> person.getGender().equals(GenderType.FEMALE) )
		   .collect(Collectors.toSet());	
	return brotherInLaw;
	}
	public SisterInLaw getInstance() {
		return new SisterInLaw();
	}

	

}
