package com.family.relation;

import java.util.Set;

import com.family.bean.Person;

public interface Relation {
	
	public Set<Person> get(Person person);

	public Relation getInstance();

}
