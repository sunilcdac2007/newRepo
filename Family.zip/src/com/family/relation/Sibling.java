package com.family.relation;

import java.util.Set;
import com.family.bean.Person;

public class Sibling implements Relation {

	public Set<Person> get(Person currentPerson){
		return currentPerson.getSiblings();
	}
	public Sibling getInstance() {
		return new Sibling();
	}
}
