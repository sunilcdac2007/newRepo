package com.family.relation;

import java.util.Set;
import java.util.stream.Collectors;

import com.family.bean.GenderType;
import com.family.bean.Person;

public class Son implements Relation {

	public Set<Person> get(Person currentPerson){
		return currentPerson.getChildrens().stream()
				   .filter(person -> person.getGender().equals(GenderType.MALE) )
				   .collect(Collectors.toSet());
	}
	public Son getInstance() {
		return new Son();
	}

}
