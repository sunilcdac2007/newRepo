package com.family.command;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import com.family.bean.Person;
import com.family.tree.Family;
import com.family.util.Util;

public class Command {
	
	List<String> supportedAction = Arrays.asList("ADD_CHILD","ADD_SPOUSE","GET_RELATIONSHIP");
	public void execute(String command, Family family) {
		
		String[] args = command.split(" ");
		if(!supportedAction.contains(args[0])) {
			System.out.println(args[0] +" command not supported");
		}
		switch(args[0]) {
		case "ADD_CHILD":
			if(args.length != 4) {
				System.out.println("CHILD_ADITION_FAILED");
				break;
			}
			boolean isAdded = family.addChild(args[1], args[2], Util.getGenderType(args[3]));
			if(isAdded)
				System.out.println("CHILD_ADDITION_SUCCEEDED");
		
			break;
		case "ADD_SPOUSE":
			if(args.length != 5) {
				System.out.println("SPOUSE_ADITION_FAILED");
				break;
			}
			family.addSpouse(args[1],Util.getGenderType(args[2]), args[3], Util.getGenderType(args[4]));
		    break;
		case "GET_RELATIONSHIP":
			if(args.length != 3) {
				System.out.println("PERSON_NOT_FOUND");
				break;
			}
			Set<Person> persons = family.getRelationShip(args[1],Util.getRelationType(args[2]));
			if(persons == null) {
				System.out.println("PERSON_NOT_FOUND");
			}
			if(persons.size() == 0) {
				System.out.println("NONE");
			}
			persons.stream().forEach(person->System.out.print(person.getName() +" "));
			System.out.println();
			break;
		default :
			System.out.println("Action not listed");
		}
		
		
	}

}
