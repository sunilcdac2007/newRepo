package com.family.tree;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import com.family.bean.GenderType;
import com.family.bean.Person;
import com.family.bean.Person.PersonBuilder;
import com.family.relation.RelationType;
import com.family.relation.RelationshipManager;
import com.family.util.PersonUtil;

public class Family {
	
	private Person head;
	
	public Person getHead() {
		return head;
	}

public Family initiateFamily(String kingName, String queenName) {
		Person king = new PersonBuilder(kingName, GenderType.MALE).build();
		Person queen = new PersonBuilder(queenName, GenderType.FEMALE).build();
		this.addKing(king);
		this.addQueen(queen);
		return this;	
	}
	public void addKing(Person person) {
		head = person;
		person.setGenerationLavel(0);
	}

	public void addQueen(Person queen) {
		if (null != head) {
			head.setSpouse(queen);
			queen.setSpouse(head);
			queen.setGenerationLavel(0);
		}
	}
	
	public void addSpouse(Person person) {
		if (null != person.getSpouse()) {
			Person temp = head;
			addSpouse(person, temp);
		}
	}
	
	private boolean addSpouse(Person person, Person temp) {
		boolean spouseAdded = false;
		while (null != temp) {
			if (temp.equals(person.getSpouse())) {
				person.setGenerationLavel(temp.getGenerationLavel());
				temp.setSpouse(person);
				spouseAdded = true;
			}
			if (null != temp.getChildrens() && !spouseAdded) {
				for (Person p : temp.getChildrens()) {
					spouseAdded = !spouseAdded ? addSpouse(person, p)
							: spouseAdded;
				}
			}
			temp = null;
		}
		return spouseAdded;
	}
	
	
	
	public boolean addChild(String motherName, String childName, GenderType gender) {
		Person mother = PersonUtil.getPersonByName(head, motherName);
		if(mother == null) {
			System.out.println("PERSON_NOT_FOUND");
			return false;
		}
		try {
		Person child = new PersonBuilder(childName,gender)
				           .setMonther(mother)
				           .setFather(mother.getSpouse())
				           .build();
		// updating siblings
		child.setSiblings(mother.getChildrens());
		for(Person person: mother.getChildrens()) {
			Set<Person> sibling =ConcurrentHashMap.newKeySet(person.getSiblings().size());
			for(Person sib: person.getSiblings()) {
				if(!person.getName().equals(sib.getName()))
					sibling.add(sib);
			}
			sibling.add(child);
			person.setSiblings(sibling);
		}
		mother.addChildren(child);
		mother.getSpouse().addChildren(child);		
		return true;
		}catch(Exception ex) {
			System.out.println("CHILD_ADITION_FAILED");
			return false;
		}
	}

	public boolean addSpouse(String firstPattnerName, GenderType firstGender, 
			String secondPattnerName, GenderType secondGender ) {
		if(firstGender.equals(secondGender)) {
			return false;
		}
		Person firstPerson = PersonUtil.getPersonByName(head, firstPattnerName); 
		
		Person secondPerson = PersonUtil.getPersonByName(head, secondPattnerName);
		
		if(firstPerson == null && secondPerson == null) {
			System.out.println("these will be not part of family");
			return false;
		}
		
		if (firstPerson!= null && secondPerson != null && firstPerson.getFather().getName().equals(secondPerson.getFather().getName())
			&& firstPerson.getMonther().getName().equals(secondPerson.getMonther().getName())){
			System.out.println("They can't be spouse");
			return false;
		}
		
		if(firstPerson == null) {
			firstPerson = new PersonBuilder(firstPattnerName, firstGender).build();
		}
		
		if(secondPerson == null) {
			secondPerson = new PersonBuilder(secondPattnerName, secondGender).build();
		}
	
		firstPerson.setSpouse(secondPerson);
		secondPerson.setSpouse(firstPerson);
		
		return true;
	}
	
	public Set getRelationShip(String name, RelationType relationType) {
		RelationshipManager relationshipManager = new RelationshipManager();
		Person person = PersonUtil.getPersonByName(head, name);
		if(person == null) {
			return null;
		}
		return relationshipManager.getPeopleWithRelationship(relationType, person);
	}

}
