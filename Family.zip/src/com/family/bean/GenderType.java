package com.family.bean;

public enum GenderType {
    MALE, FEMALE, NOTSUPPORTED
}
