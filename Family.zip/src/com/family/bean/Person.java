package com.family.bean;

import java.util.HashSet;
import java.util.Set;

public class Person {

	private String name;	
	private GenderType gender;
	private Person spouse;
	private Person monther;
	private Person father;	
	private boolean isMaried;
	private Set<Person> childrens;
	private Set<Person> siblings;
	private int generationLavel;
	
	
	
	public Set<Person> getSiblings() {
		return siblings;
	}

	public void setSiblings(Set<Person> siblings) {
		this.siblings = siblings;
	}

	public int getGenerationLavel() {
		return generationLavel;
	}

	public void setGenerationLavel(int generationLavel) {
		this.generationLavel = generationLavel;
	}

	public void addChildren(Person person) {

		this.childrens = null == this.childrens ? new HashSet<Person>()
				: this.childrens;

		this.childrens.add(person);
	}
	
	public Person getSpouse() {
		return spouse;
	}
	public void setSpouse(Person spouse) {
		this.spouse = spouse;
	}
	public Person getMonther() {
		return monther;
	}
	public void setMonther(Person monther) {
		this.monther = monther;
	}
	public Person getFather() {
		return father;
	}
	public void setFather(Person father) {
		this.father = father;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public GenderType getGender() {
		return gender;
	}
	public void setGender(GenderType gender) {
		this.gender = gender;
	}

	public boolean isMaried() {
		return isMaried;
	}
	public void setMaried(boolean isMaried) {
		this.isMaried = isMaried;
	}
	public Set<Person> getChildrens() {
		return childrens;
	}
	public void setChildrens(Set<Person> childrens) {
		this.childrens = childrens;
	}
	
	private Person(PersonBuilder builder) {
		this.name = builder.name;
		this.gender = builder.gender;
		this.isMaried = builder.isMaried;
		this.father = builder.father;
		this.monther = builder.monther;
		this.spouse = builder.spouse;
		this.childrens = builder.childrens;
		this.siblings = builder.siblings;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	public static class PersonBuilder{
		
		private String name;	
		private GenderType gender;
		
		public PersonBuilder(String name, GenderType gender) {
			super();
			this.name = name;
			this.gender = gender;
			this.childrens = new HashSet<>();
			this.siblings = new HashSet<>();
		}
		private Person spouse;
		private Person monther;
		private Person father;	
		private boolean isMaried;
		private Set<Person> childrens;
		private Set<Person> siblings;

		public PersonBuilder setSpouse(Person spouse) {
			this.spouse = spouse;
			return this;
		}
		public PersonBuilder setMonther(Person monther) {
			this.monther = monther;
			return this;
		}
		public PersonBuilder setFather(Person father) {
			this.father = father;
			return this;
		}
		public PersonBuilder setMaried(boolean isMaried) {
			this.isMaried = isMaried;
			return this;
		}
		public PersonBuilder setChildrens(Set<Person> childrens) {
			this.childrens = childrens;
			return this;
		}
		
	 public Person build() {
		 return new Person(this);
	 }
		
	}
	
}
