package com.family.main;

import java.util.List;

import com.family.command.Command;
import com.family.tree.Family;
import com.family.util.Util;

public class Geektrust {
	
	public static void main(String args[]) {
		String filepath = args[0];
		Command cmd = new Command();
		Family family = new Family();
		family = family.initiateFamily("Shan", "Anga");
		/*
		 *  // populate initial family
		 * Structure List<String> createCommand =
		 * Util.readInputFile("InitialFamilyTree.txt"); for(String command:
		 * createCommand) cmd.execute(command, family); // family structure created
		 */		//"F:\\FamilytreeTest.txt"
		List<String> commands = Util.readInputFile(filepath);
		for(String command: commands)
			cmd.execute(command, family);
	}	
	
	
	
}
