package com.family.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.family.bean.GenderType;
import com.family.relation.RelationType;

public class Util {
	
	public static List<String> readInputFile(String fileLocation){
		List<String> commands = new ArrayList<String>();
		try {
			Scanner scaner = new Scanner(new File(fileLocation));
			scaner.useDelimiter("[;\r\n]+");
			while(scaner.hasNext()) {
				commands.add(scaner.next().trim());
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return commands;
	}
	
	public static GenderType getGenderType(String gender) {
		GenderType genderout=null;
		if(gender.equalsIgnoreCase("male")) {
			genderout = GenderType.MALE;
		} else if(gender.equalsIgnoreCase("female")) {
			genderout = GenderType.FEMALE;
		} else {
			genderout = GenderType.NOTSUPPORTED;
		}
		return genderout;
	}
	
	public static RelationType getRelationType(String relationType) {
		
		RelationType type=null;
		
		if(relationType.equalsIgnoreCase("Brother-In-Law")) {
			type = RelationType.BROTHERINLAW;
		} else if(relationType.equalsIgnoreCase("Sister-In-Law")) {
			type = RelationType.SISTERINLAW;
		}else if(relationType.equalsIgnoreCase("Brother")) {
			type = RelationType.BROTHERS;
		}else if(relationType.equalsIgnoreCase("sibling")) {
			type = RelationType.SIBLING;
		}else if(relationType.equalsIgnoreCase("son")) {
			type = RelationType.SON;
		}else if(relationType.equalsIgnoreCase("daughter")) {
			type = RelationType.DAUGHTER;
		}else if(relationType.equalsIgnoreCase("sister")) {
			type = RelationType.SISTERS;
		}else if(relationType.equalsIgnoreCase("maternal-ant")) {
			type = RelationType.MATERNALAUNT;
		}else if(relationType.equalsIgnoreCase("paternal-ant")) {
			type = RelationType.PATERNALAUNT;
		}else if(relationType.equalsIgnoreCase("paternal-uncle")) {
			type = RelationType.PATERNALUNCLE;
		}else if(relationType.equalsIgnoreCase("maternal-uncle")) {
			type = RelationType.MATERNALUNCLE;
		}
		return type;
		
	}

}
