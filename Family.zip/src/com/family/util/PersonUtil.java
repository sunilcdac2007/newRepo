package com.family.util;

import java.util.HashSet;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeMap;

import com.family.bean.GenderType;
import com.family.bean.Person;

public class PersonUtil {

	
	public static Person getPersonByName(Person currentPerson, String name) {	
		Person person = null;

		if (currentPerson.getName().equalsIgnoreCase(name)) {
			return currentPerson;
		} else if (null != currentPerson.getSpouse()
				&& currentPerson.getSpouse().getName().equalsIgnoreCase(name)) {
			return currentPerson.getSpouse();
		}

		if (null != currentPerson.getChildrens()) {
			for (Person p : currentPerson.getChildrens()) {
				person = getPersonByName(p, name);
				if (null != person) {
					break;
				}
			}
		}
		return person;
	}
	
	
	public Person getGenerationDiff(String name1, String name2, Person head) {
		Person temp = head;
		Person firstPerson = getPersonByName(temp, name1);
		Person secondPerson = getPersonByName(temp, name2);
		return firstPerson.getGenerationLavel() < secondPerson.getGenerationLavel() 
				? firstPerson
				: secondPerson;
	}
	private void addMothertoMap(Person temp,
			NavigableMap<Integer, Set<Person>> motherMap) {

		int count = 0;

		if (null != temp.getChildrens()) {
			for (Person p : temp.getChildrens()) {
				count = p.getGender().equals(GenderType.FEMALE) ? count + 1 : count;
			}

			if (motherMap.containsKey(count)) {
				motherMap.get(count).add(temp);
			} else {
				Set<Person> tempSet = new HashSet<Person>();
				tempSet.add(temp);
				motherMap.put(count, tempSet);
			}
		}
	}
	
	private Set<Person> getMotherWithMaxGirlChild(Person temp,
			NavigableMap<Integer, Set<Person>> motherMap) {

		if (temp.getGender().equals(GenderType.FEMALE)) {
			addMothertoMap(temp, motherMap);
		} else if (null != temp.getSpouse()
				&& temp.getSpouse().getGender().equals(GenderType.FEMALE)) {
			addMothertoMap(temp.getSpouse(), motherMap);
		}

		if (null != temp.getChildrens()) {
			for (Person p : temp.getChildrens()) {
				getMotherWithMaxGirlChild(p, motherMap);
			}
		}
		return motherMap.lastEntry().getValue();
	}
	
	public Set<Person> getMaxGirlChildMother(Person head) {
		NavigableMap<Integer, Set<Person>> motherMap = new TreeMap<Integer, Set<Person>>();
		return getMotherWithMaxGirlChild(head, motherMap);
	}

}
